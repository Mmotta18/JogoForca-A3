package servidor;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

import cliente.cliente;
import cliente.jogoForca;

import java.io.PrintStream;


public class servidor {

    public static void main(String[] args){
        final int PORT = 8000;
        ServerSocket serverSocket;
        Socket clientSocket = null;
        Scanner input = null;
        PrintStream output = null;


        // Criação do Socket
        try{
            serverSocket = new ServerSocket(PORT);
        }catch(Exception e){
            System.out.println("Porta" + PORT + "indisponível");
            System.out.println(e.getMessage());
            return;
        }

        // Aguardando conexão

        try{
           cliente client = new cliente();
           System.out.println("Aguardando conexão...");
           client.main();
           clientSocket = serverSocket.accept();
        }catch(Exception e){
            System.out.println(e.getMessage());
        }

        // Comunicação
        try {
            input = new Scanner(
                clientSocket.getInputStream() 
            );
            output = new PrintStream(
                clientSocket.getOutputStream()
            );
	    } catch (Exception e) {
	           System.out.println("Erro na comunicação");
	           System.out.println(e.getMessage());
	        }
	
	        // Encerrar conexão
	        try {
	            input.close();
	            output.close();
	            clientSocket.close();
	            serverSocket.close();
	        } catch (Exception e) {
	            System.out.println(e.getMessage());
	        }
            
        
    } 
}

