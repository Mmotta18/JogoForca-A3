package cliente;

import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;
import java.io.IOException;
import java.io.PrintStream;

public class cliente {
    public void main() {
        final String IP = "127.0.0.1";
        final int PORT = 8000;    
        Socket socket = null;
        Scanner input = null;
        Scanner teclado;
        PrintStream output = null;
        

        // Solicitação de conexão 
        try {
            socket = extracted(IP, PORT);
        } catch (Exception e) {
            System.out.println("Não foi possível se conectar ao servidor : ");
            System.out.println(e.getMessage());
            return;
        
        }

        // Comunicação 
        try {
            input = new Scanner(socket.getInputStream());
            output = new PrintStream(socket.getOutputStream());

            teclado = new Scanner(System.in);

            String msg;
            jogoForca jogoDaForca = new jogoForca();

            do{
                System.out.println("Olá! O jogo vai começar. Bom jogo!");
                msg = teclado.nextLine();
                if(msg.equals("exit"))
                {
                	teclado.close();
                	System.out.println("Obrigado por jogar!");
                }
                else
                {
                    output.println(jogoDaForca);
                    jogoDaForca.forca();
                }
            }while(!msg.equalsIgnoreCase("exit"));

        } catch (Exception e) {
            System.out.println("Erro na comunicação");
            System.out.println(e.getMessage());
        }

    }

    private static Socket extracted(final String IP, final int PORT) throws UnknownHostException, IOException {
        Socket socket;
        socket = new Socket(IP, PORT);
        return socket;
    }
}