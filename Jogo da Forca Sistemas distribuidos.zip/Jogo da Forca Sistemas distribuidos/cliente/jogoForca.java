package cliente;

import java.util.Scanner; 

    // Jogo da Forca     
    public class jogoForca {
    	public void forca() {
		    int maxTentativas = 10;
		    String  keyWord = "paralelepipedo";
		    String letrasUtilizadas = "";
		    String palavraAdivinhada = "";

    

    

    for(int i = 0; i < keyWord.length(); i++){
        palavraAdivinhada += "_";

        for(int tentativas = 0;;tentativas++){
            if (tentativas == maxTentativas) {
                System.out.println("Suas tentativas acabaram! A palavra era " + keyWord);
                System.exit(0);
            }

            System.out.printf("Rodada %d, Até aora você adivinhou: %s. Qual a próxima letra?", tentativas, palavraAdivinhada);

            char letraTentada = new Scanner(System.in).next().charAt(0);
            if(letrasUtilizadas.indexOf(letraTentada) >=0){
                System.out.printf("Você já tentou a letra %c, Tente outra" , letraTentada);
            }else{letrasUtilizadas += letraTentada;
                if(keyWord.indexOf(letraTentada) >=0 ){
                    palavraAdivinhada = "";

                for(int letra = 0; letra < keyWord.length(); letra++){
                    palavraAdivinhada += letrasUtilizadas.indexOf(keyWord.charAt(letra)) >= 0 ? keyWord.charAt(letra): "_";
                }    
                if(palavraAdivinhada.contains("_")){
                    System.out.printf("Parabéns! %s pertence a palavra." , letraTentada);
                }else{
                    System.out.println("Parabéns! Você adivinhou.");
                    System.exit(0);;
                }
                }else{
                    System.out.printf("Não tem letra %c na palavra", letraTentada);
                }
            }

        }
    }
    }
            
    }
    